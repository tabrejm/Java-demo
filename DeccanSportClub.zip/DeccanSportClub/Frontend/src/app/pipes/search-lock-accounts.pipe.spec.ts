import { SearchLockAccountsPipe } from './search-lock-accounts.pipe';

describe('SearchLockAccountsPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchLockAccountsPipe();
    expect(pipe).toBeTruthy();
  });
});
