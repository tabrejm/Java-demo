import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchAccount'
})
export class SearchAccountPipe implements PipeTransform {

  transform(value: any[], args: string): any {
    if(!value) return null;
    if(!args) return value;
    
    let search=args.toLowerCase();
    return value.filter(account => { 
      let sport_name=account.name.toLowerCase(); 
      return sport_name.indexOf(search) !== -1;});
  }

}
