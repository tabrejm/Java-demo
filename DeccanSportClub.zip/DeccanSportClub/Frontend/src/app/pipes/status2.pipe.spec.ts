import { Status2Pipe } from './status2.pipe';

describe('Status2Pipe', () => {
  it('create an instance', () => {
    const pipe = new Status2Pipe();
    expect(pipe).toBeTruthy();
  });
});
