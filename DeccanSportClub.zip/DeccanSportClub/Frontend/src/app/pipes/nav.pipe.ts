import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nav'
})
export class NavPipe implements PipeTransform {

  transform(value: string, ...args: string[]): string {
    return value.replace('_',args[0]);
  }

}
