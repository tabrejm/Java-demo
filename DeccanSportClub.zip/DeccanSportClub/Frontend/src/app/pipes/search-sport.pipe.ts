import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchSport'
})
export class SearchSportPipe implements PipeTransform {

  transform(value: any[], args: string): any {
    if(!value) return null;
    if(!args) return value;
    
    let search=args.toLowerCase();
    return value.filter(sport => { 
      let sport_name=sport.sportName.toLowerCase(); 
      return sport_name.indexOf(search) !== -1;});
  }
}
