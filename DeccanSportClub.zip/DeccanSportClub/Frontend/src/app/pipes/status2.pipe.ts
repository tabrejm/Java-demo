import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'status2'
})
export class Status2Pipe implements PipeTransform {

  transform(value: string, ...args: string[]): string {
    return value.replace('false',args[0]);
  }

}
