import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { User } from '../models/user';
import { HttpClient, HttpParams } from '@angular/common/http';
import { LoginRequest } from '../models/loginRequest';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {



  private apiServelUrl = environment.apiBaseUrl;
  constructor(private http : HttpClient) { }

  authenticate(loginRequest : LoginRequest) : Observable<any> {
    
    return this.http.post<any>(`${this.apiServelUrl}/login`,loginRequest);

  
     
    /*
    if(username === "admin" && password === "admin") {
      sessionStorage.setItem('username', username)
      return true;
    }
    else if(username == 'manager' && password === 'manager') {
      sessionStorage.setItem('username', username)
      return true;
    }
    else {
      return false;
    }
    */
  }

  registerUser(user : User) : Observable<User[]> {
    return this.http.post<User[]>(`${this.apiServelUrl}/register`,user);
  }

  

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}
