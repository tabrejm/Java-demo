import { Injectable } from '@angular/core';
import { Batches } from '../models/batches';
import { Enrollment } from '../models/enrollments';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor() { }
  

 

  
}
