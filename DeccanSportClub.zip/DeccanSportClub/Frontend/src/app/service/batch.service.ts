import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Batches } from '../models/batches';

@Injectable({
  providedIn: 'root'
})
export class BatchService {

  private apiServelUrl = environment.apiBaseUrl;

  constructor(private http : HttpClient) { }

  //get all batches
  public getBatches() : Observable<Batches[]> {
    return this.http.get<Batches[]>(`${this.apiServelUrl}/batch/all`);
  }

  //get batch by id
  getBatchById(id : number) : Observable<Batches> {
    return this.http.get<Batches>(`${this.apiServelUrl}/batch/find/${id}`);
  }

  //add a batch
  public addBatch(batch : Batches) : Observable<Batches> {
    return this.http.post<Batches>(`${this.apiServelUrl}/batch/add`, batch);
  }

  //update a batch
  public updateBatch(id : number, batch : Batches) : Observable<Batches> {
    return this.http.put<Batches>(`${this.apiServelUrl}/batch/update/${id}`, batch);
  }

  //delete a batch
  public deleteBatch(id : number) : Observable<void> {
    return this.http.delete<void>(`${this.apiServelUrl}/batch/delete/${id}`);
  }
}
