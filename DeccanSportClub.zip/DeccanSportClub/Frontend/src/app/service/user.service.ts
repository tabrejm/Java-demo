import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Comments } from '../models/comments';
import { Offers } from '../models/offers';
import { User } from '../models/user';
import { Enrollment } from '../models/enrollments';
import { UpdateEnrollment } from '../models/updateEnrollment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiServelUrl = environment.apiBaseUrl+'/user';
  private apiServelUrl1 = environment.apiBaseUrl;

  constructor(private http : HttpClient) { }

  //get all users
  public getUsers() : Observable<User[]> {
    return this.http.get<User[]>(`${this.apiServelUrl}/all`);
  }

  //get onlu users
  public getOnlyUsers() : Observable<User[]> {
    return this.http.get<User[]>(`${this.apiServelUrl}/fetchUsers`);
  }

  //get all comments
  public getComments() : Observable<Comments[]> { 
    return this.http.get<Comments[]>(`${this.apiServelUrl1}/allComments`);
  }

  //getAllOffers
  public getAllOffers() : Observable<Offers[]> {
    return this.http.get<Offers[]>(`${this.apiServelUrl1}/allOffers`);
  }
  
  //add comment
  public addComment(comment : Comments) : Observable<Comments> {
    return this.http.post<Comments>(`${this.apiServelUrl1}/addComment`, comment);
  }

  //get batch by id
  getUserById(id : number) : Observable<User> {
    return this.http.get<User>(`${this.apiServelUrl}/find/${id}`);
  }

  //get enrollment status
  getEnrollmentStatus() : Observable<User[]> {
    return this.http.get<User[]>(`${this.apiServelUrl}/enrollment/approved`);
  }

  //getAll Enrollments
  public getAllEnrollments() : Observable<Enrollment[]> {
    return this.http.get<Enrollment[]>(`${this.apiServelUrl}/enrollments`);
  }

  //add enrollment
  public addEnrollment(id:number,enrollment : Enrollment) : Observable<Enrollment> {
    return this.http.post<Enrollment>(`${this.apiServelUrl}/addEnrollment/${id}`, enrollment);
  }

  //update enrollment
  public updateEnrollment(userId:number,enrollment : UpdateEnrollment) : Observable<UpdateEnrollment> {
    return this.http.put<UpdateEnrollment>(`${this.apiServelUrl}/enrollment/update/${userId}`, enrollment);
  }



}
