import { TestBed } from '@angular/core/testing';

import { LockAccountServiceService } from './lock-account-service.service';

describe('LockAccountServiceService', () => {
  let service: LockAccountServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LockAccountServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
