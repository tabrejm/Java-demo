import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ISport } from '../models/sport';



@Injectable({
  providedIn: 'root'
})
export class SportService {

  private apiServelUrl = environment.apiBaseUrl;

  


  constructor(private http : HttpClient) { }
         
  //get all sports
  public getAllSports() : Observable<ISport[]> {

    return this.http.get<ISport[]>(`${this.apiServelUrl}/sport/getAllSports`);
  }

  

   //add a sport
   public addSport(sport : ISport) : Observable<String> {
     
        return  this.http.post<String>(`${this.apiServelUrl}/sport/addSport`,sport);
  }


  
  deleteSport(sportId:number):Observable<String>
  {
    return this.http.delete<String>(`${this.apiServelUrl}/sport/delete/${sportId}`);

  }

  
   updateSport(updated_sport:ISport):Observable<ISport>
   {
   

    return  this.http.put<ISport>(`${this.apiServelUrl}/sport/edit`,updated_sport );
     
   }


    searchSport(sportId:number):Observable<ISport>
   {
    return this.http.get<ISport>(`${this.apiServelUrl}/sport/get_sport/${sportId}`);

   }

   

}
