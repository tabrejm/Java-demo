import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AccountEmail } from '../models/accountEmail';


@Injectable({
  providedIn: 'root'
})
export class MailServiceService {

  
  private apiServelUrl = environment.apiBaseUrl+'/send';

  constructor(private http : HttpClient) { }

   public sendAccountEmail(id:any,accountEmail:AccountEmail) : Observable<any> {

     
        return  this.http.post<any>(`${this.apiServelUrl}/${id}`,accountEmail);
  }
}
