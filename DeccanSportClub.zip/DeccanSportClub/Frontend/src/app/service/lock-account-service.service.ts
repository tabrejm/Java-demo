import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LockAccount } from '../models/lockAccount';

@Injectable({
  providedIn: 'root'
})
export class LockAccountServiceService {


  private apiServerUrl = environment.apiBaseUrl+'/lock_account';


  constructor(private http : HttpClient) { }

  
  //get all lockAccounts
  public getAllLockedAccounts() : Observable<LockAccount[]> {
    return this.http.get<LockAccount[]>(`${this.apiServerUrl}/all`);
  }

  public getLockAccountById(id:number) : Observable<LockAccount> {
    return this.http.get<LockAccount>(`${this.apiServerUrl}/find/${id}`);
  }

  public getLockAccountByEmail(email:string) : Observable<LockAccount> {
    return this.http.get<LockAccount>(`${this.apiServerUrl}/find_email/${email}`);
  }

  public addLockedAccount(account:LockAccount):Observable<LockAccount>
  {
    return this.http.post<LockAccount>(`${this.apiServerUrl}/add`,account);
  }

  public deletelockedAccount(account_id:number):Observable<any>
  {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    return this.http.delete(`${this.apiServerUrl}/delete/${account_id}`,{headers, responseType:'text'});

  }

}
