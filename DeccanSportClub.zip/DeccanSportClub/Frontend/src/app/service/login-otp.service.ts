import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AccountEmail } from '../models/accountEmail';
import { LoginRequest } from '../models/loginRequest';

@Injectable({
  providedIn: 'root'
})
export class LoginOtpService {

  private apiServelUrl = environment.apiBaseUrl;

  constructor(private http : HttpClient) { }

   public sendLoginOtp(user:AccountEmail) : Observable<any> {

        return  this.http.post<any>(`${this.apiServelUrl}/send_otp`,user);
  }

  public LoginUsingOtp(user:AccountEmail) : Observable<any> {
    return  this.http.post<any>(`${this.apiServelUrl}/login_using_otp`,user);
}
}
