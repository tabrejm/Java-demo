export class AccountEmail {
    email : string = ""
}