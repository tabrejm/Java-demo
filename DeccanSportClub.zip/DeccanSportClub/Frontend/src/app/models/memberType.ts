import { EnumType } from "typescript";

export enum MembershipType {
    "SILVER","GOLD", "PLATINUM"
}