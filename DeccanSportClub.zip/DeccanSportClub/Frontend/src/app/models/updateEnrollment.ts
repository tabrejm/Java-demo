export interface UpdateEnrollment{
    id:number;
    approveRequest:boolean;
}