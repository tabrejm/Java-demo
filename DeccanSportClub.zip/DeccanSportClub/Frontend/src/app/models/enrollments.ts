export class Enrollment
{
    approveRequest! : boolean;

}