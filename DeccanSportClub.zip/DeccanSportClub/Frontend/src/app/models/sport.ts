export interface ISport
{
    sport_id:number;
    sport_name:string;
}