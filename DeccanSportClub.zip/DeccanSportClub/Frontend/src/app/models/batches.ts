import { Time } from "@angular/common";
export class Batches {
    id! : number;
    batchName : string = "";
    startDate : Date = new Date();
    endDate : Date = new Date();
    time!: Time; 
    imageUrl : string = ""

}