export class Comments {
    id! : number ;
    message : string = "";
    userId! :any 
}