import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountsComponent } from './components/accounts/accounts.component';
import { AddSportComponent } from './components/add-sport/add-sport.component';
import { AddmanagerComponent } from './components/addmanager/addmanager.component';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { BatchDetailsComponent } from './components/batch-details/batch-details.component';
import { BatchListComponent } from './components/batch-list/batch-list.component';
import { BatchesComponent } from './components/batches/batches.component';
import { CreateBatchComponent } from './components/create-batch/create-batch.component';
import { GenerateReportsComponent } from './components/generate-reports/generate-reports.component';
import { HomeComponent } from './components/home/home.component';
import { LockAccountsComponent } from './components/lock-accounts/lock-accounts.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { MembershipComponent } from './components/membership/membership.component';
import { NavComponent } from './components/nav/nav.component';
import { OffersComponent } from './components/offers/offers.component';
import { RegisterComponent } from './components/register/register.component';
import { SportsComponent } from './components/sports/sports.component';
import { UpdateBatchComponent } from './components/update-batch/update-batch.component';
import { UpdateSportComponent } from './components/update-sport/update-sport.component';
import { UserComponent } from './components/user/user.component';
import { Batches } from './models/batches';
import { AdminService } from './service/admin.service';
import { AuthGaurdService } from './service/auth-gaurd.service';

const routes: Routes = [
  { path : '' , component : HomeComponent},
  { path : 'register',  component : RegisterComponent},
  { path : 'login', component : LoginComponent },
  { path : 'user', component : UserComponent},
  { path : 'batches', component: BatchesComponent},
  { path : 'manager', component : BatchListComponent },
  { path : 'create-batch', component : CreateBatchComponent },
  { path : 'updateBatch/:id', component : UpdateBatchComponent },
  { path : 'batchDetails/:id', component : BatchDetailsComponent },
  { path : 'offers', component:OffersComponent },
  { path : 'Logout', component : LogoutComponent },
  { path : 'nav', component : NavComponent },
  { path : 'sports', component : SportsComponent },
  { path : 'admin' , component : AdminHomeComponent},
  { path:"View_Sports", component:SportsComponent},
  { path:"updateSport/:id", component:UpdateSportComponent},
  { path:"View_Sports/addSport", component:AddSportComponent},
  { path:"Add_Manager", component:AddmanagerComponent},
  { path:"Reports", component:GenerateReportsComponent},
  { path:"Accounts", component:AccountsComponent},
  { path:"membership", component:MembershipComponent },
  { path:"Lock_Accounts", component:LockAccountsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
