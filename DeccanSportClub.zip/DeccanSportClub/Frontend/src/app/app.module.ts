import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavigationComponent } from './components/navigation/navigation.component';
import { MaterialModule } from './material/material.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CarouselsComponent } from './components/carousels/carousels.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CardsComponent } from './components/cards/cards.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { LogoutComponent } from './components/logout/logout.component';
import { UserComponent } from './components/user/user.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { HeaderComponent } from './components/header/header.component';
import { UserHomeComponent } from './components/user-home/user-home.component';
import { OffersComponent } from './components/offers/offers.component';
import { BatchesComponent } from './components/batches/batches.component';
import { BatchListComponent } from './components/batch-list/batch-list.component';
import { CreateBatchComponent } from './components/create-batch/create-batch.component';
import { UpdateBatchComponent } from './components/update-batch/update-batch.component';
import { BatchDetailsComponent } from './components/batch-details/batch-details.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { GenerateReportsComponent } from './components/generate-reports/generate-reports.component';
import { NavComponent } from './components/nav/nav.component';
import { SportsComponent } from './components/sports/sports.component';
import { SearchSportPipe } from './pipes/search-sport.pipe';
import { NavPipe } from './pipes/nav.pipe';
import { UpdateSportComponent } from './components/update-sport/update-sport.component';
import { AddSportComponent } from './components/add-sport/add-sport.component';
import { AddmanagerComponent } from './components/addmanager/addmanager.component';
import { CommentsComponent } from './components/comments/comments.component';
import { AccountDialogComponent } from './components/account-dialog/account-dialog.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { SearchAccountPipe } from './pipes/search-account.pipe';
import { MembershipComponent } from './components/membership/membership.component';
import { LockAccountsComponent } from './components/lock-accounts/lock-accounts.component';
import { SearchLockAccountsPipe } from './pipes/search-lock-accounts.pipe';
import { LoginOtpDialogComponent } from './components/login-otp-dialog/login-otp-dialog.component';
import { StatusPipe } from './pipes/status.pipe';
import { Status2Pipe } from './pipes/status2.pipe';
//import  html2canvas  from 'html2canvas';
//import  html2PDF  from 'jspdf-html2canvas';





@NgModule({
  declarations: [
    
    AppComponent,
    NavigationComponent,
    CarouselsComponent,
    CardsComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    LogoutComponent,
    UserComponent,
    SidenavComponent,
    HeaderComponent,
    UserHomeComponent,
    OffersComponent,
    BatchesComponent,
    BatchListComponent,
    CreateBatchComponent,
    UpdateBatchComponent,
    BatchDetailsComponent,
    AdminComponent,
    AdminHomeComponent,
    GenerateReportsComponent,
    NavComponent,
    SportsComponent,
    SearchSportPipe,
    NavPipe,
    UpdateSportComponent,
    AddSportComponent,
    AddmanagerComponent,
    CommentsComponent,
    AccountDialogComponent,
    AccountsComponent,
    SearchAccountPipe,
    MembershipComponent,
    LockAccountsComponent,
    SearchLockAccountsPipe,
    LoginOtpDialogComponent,
    StatusPipe,
    Status2Pipe,
    //html2canvas,
    //html2PDF
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
