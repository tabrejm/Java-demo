import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LockAccountsComponent } from './lock-accounts.component';

describe('LockAccountsComponent', () => {
  let component: LockAccountsComponent;
  let fixture: ComponentFixture<LockAccountsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LockAccountsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LockAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
