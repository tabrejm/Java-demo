import { Component, OnInit } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { PRIMARY_OUTLET } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  links:string[]=["Home","View_Sports","Add_Manager","View_Logs","Reports","Accounts","Lock_Accounts","Logout"];
  activeLink = this.links[0];
  background: ThemePalette = PRIMARY_OUTLET;

  constructor() { }

  ngOnInit(): void {
  }

}
