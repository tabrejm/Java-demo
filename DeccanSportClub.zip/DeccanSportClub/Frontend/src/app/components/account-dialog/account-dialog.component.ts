import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MailServiceService } from 'src/app/service/mail-service.service';
import { ActivatedRoute } from '@angular/router';
import { AccountEmail } from 'src/app/models/accountEmail';

@Component({
  selector: 'app-account-dialog',
  templateUrl: './account-dialog.component.html',
  styleUrls: ['./account-dialog.component.scss']
})
export class AccountDialogComponent implements OnInit {

  emailId= new FormControl('',[Validators.required])
  id:any;
  constructor(public dialog:MatDialog,private mailService:MailServiceService,private activatedRoute:ActivatedRoute) { } 

  ngOnInit(): void {
      this.id=sessionStorage.getItem("accountId");
  }

  sendInformation(user_email:string)
  {
    console.log("EMail "+user_email)
    console.log("Id = "+this.id);
    let account :AccountEmail={
      email:user_email
    }
       this.mailService.sendAccountEmail(this.id,account).subscribe(
         data=>{
           console.log("Data "+data);
               alert("Mail send successfully")
       }
       )
  }

}
