import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { User } from 'src/app/models/user';
import { LoginRequest } from 'src/app/models/loginRequest';
import { LockAccountServiceService } from 'src/app/service/lock-account-service.service';
import { LockAccount } from 'src/app/models/lockAccount';
import { LoginOtpDialogComponent } from '../login-otp-dialog/login-otp-dialog.component';
import { MatDialog } from '@angular/material/dialog';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  hide = true;

  user : User = new User();

  id:any;
 count:number=0;
  

  //username = 'admin'
  //password1 = 'admin'
  //invalidLogin = false

  email = new FormControl('',[Validators.required, Validators.email]);
  password= new FormControl('',[Validators.required])
  
  accountInformation:string="";

  constructor(private router : Router, private loginservice : AuthenticationService, private lockedAccountService : LockAccountServiceService,public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  login(user_email : string, user_password : string) {

    let authenticateUser:LoginRequest={
      email:user_email,
      password:user_password
    }

     this.loginservice.authenticate(authenticateUser).subscribe( 
       data => {
         console.log(data.email);
         console.log("Data = "+data.id);
         this.user=data;
         this.lockedAccountService.getLockAccountByEmail(data.email).subscribe(
           data =>
           {
              console.log(data);
            alert("Account is locked");

           }
           ,error =>
           {
            sessionStorage.setItem("role",this.user.role);
            this.id=this.user.id;
            sessionStorage.setItem("userId",this.id);
            sessionStorage.setItem("user-email",this.user.email);
           
            if(sessionStorage.getItem('role')===('ADMIN')) {
              this.router.navigate(['admin']).then(() => {
                window.location.reload();
              });;
            }
            else if(sessionStorage.getItem('role')===('MANAGER')){
              this.router.navigate(['manager']);
            }
            else
            {
            this.router.navigate(['user'])
             }
           }
         );

       },error => {
         if(this.count>3)
         {
          let account:LockAccount={
            email:this.email.value,
            lockedDate:new Date()

          }
          this.lockedAccountService.addLockedAccount(account).subscribe(
            data => {
              console.log(data);             
            },error =>{
              alert("Account is locked due to more than three invalid attempts");
            
            }
          )
         }
         else
         {
          console.log(error);
          this.count=this.count + 1;
          console.log(this.count)
          alert("Invalid credentials");
         }

       }
     )
      
     
    }
    
  getErrorMessage() {
    if(this.email.hasError('required')) {
      return 'You must enter a value';
    }
    return this.email.hasError('email') ? 'Not a valid email!' : '';
  }

  openDialog() {
    const dialogRef = this.dialog.open(LoginOtpDialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
