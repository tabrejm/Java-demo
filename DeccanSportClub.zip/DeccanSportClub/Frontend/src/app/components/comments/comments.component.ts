import { Component, AfterViewInit, ViewChild, ElementRef, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Comments } from 'src/app/models/comments';
import { UserService } from 'src/app/service/user.service';


@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.scss']
})
export class CommentsComponent implements OnInit {

  comment = new FormControl('',Validators.required);

  comment_id :number = 0;
  userId : any;

  postComment: Comments[] = [];
 
  constructor(private commentService : UserService) { }


  ngOnInit() {
    this.userId = sessionStorage.getItem("userId");
    this.commentService.getComments().subscribe(data=>{
      this.postComment=data;
      this.comment_id = data.length+1;
    })
    
  }

  post(User_comment:string) {
   
        let userComment:Comments={
          id:this.comment_id,
          message:User_comment,
          userId:this.userId
        }

        console.log("user id"+userComment.userId);

    this.commentService.addComment(userComment).subscribe(data => {
      alert("Comment added successfully")
      console.log(data);
    }, error => console.log(error))
  }

 

}


