import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Output() toggleSidebarForMe : EventEmitter<any> = new EventEmitter();

  menuImage : string = "https://www.seekpng.com/png/detail/41-410093_circled-user-icon-user-profile-icon-png.png";

  userId : any;
  name : any = "";
  email : any = "";

  constructor(private router : Router) { }

  ngOnInit(): void {
    this.userId = sessionStorage.getItem("userId");
    this.name = sessionStorage.getItem("name");
    this.email = sessionStorage.getItem("user-email");

  }

  toggleSidebar() {
    this.toggleSidebarForMe.emit();

  }

  logout() {
    sessionStorage.removeItem("user-email");
    this.router.navigate(['login']);
  }

}
