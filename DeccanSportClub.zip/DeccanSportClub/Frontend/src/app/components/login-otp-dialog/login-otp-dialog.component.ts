import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AccountEmail } from 'src/app/models/accountEmail';
import { LoginRequest } from 'src/app/models/loginRequest';
import { LoginOtpService } from 'src/app/service/login-otp.service';

@Component({
  selector: 'app-login-otp-dialog',
  templateUrl: './login-otp-dialog.component.html',
  styleUrls: ['./login-otp-dialog.component.scss']
})
export class LoginOtpDialogComponent implements OnInit {

  emailId= new FormControl('',[Validators.required]);
  otp=new FormControl('',[Validators.required]);

  received_otp:string="";
  user:any
  id:any
  constructor(public dialog:MatDialog,private router:Router,private otpService:LoginOtpService) { } 


  ngOnInit(): void {

  }

  sendOtp(user_email:string)
  {

    let user:AccountEmail={
       email:user_email
    }

    this.otpService.sendLoginOtp(user).subscribe(
      data =>
      {
        console.log(data);
        this.received_otp=data;
        alert("Otp send successfully")
      }
    )
      
  }

  login(user_email:string,otp:string)
  {
    console.log("Otp = "+otp);
    console.log("Received otp = "+this.received_otp)
     if(otp==this.received_otp)
     {
       let user:AccountEmail={
         email:user_email
       }
        this.otpService.LoginUsingOtp(user).subscribe(
          data=>{
            this.user=data;
            sessionStorage.setItem("role",this.user.role);
            this.id=this.user.id;
            sessionStorage.setItem("userId",this.id);
            sessionStorage.setItem("user-email",this.user.email);
           
            if(sessionStorage.getItem('role')===('ADMIN')) {
              this.router.navigate(['admin'])
            }
            else if(sessionStorage.getItem('role')===('MANAGER')){
              this.router.navigate(['manager']);
            }
            else
            {
            this.router.navigate(['user'])
             }
           }
        )
     }

     else{
       alert("Invalid otp");
     }

  }



}
