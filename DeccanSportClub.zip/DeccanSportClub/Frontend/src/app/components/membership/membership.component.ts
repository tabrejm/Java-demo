import { Component, OnInit } from '@angular/core';
import { Membership } from 'src/app/models/membership';
import { MembershipService } from 'src/app/service/membership.service';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-membership',
  templateUrl: './membership.component.html',
  styleUrls: ['./membership.component.scss']
})
export class MembershipComponent implements OnInit {
  sideBarOpen = true;

  selectedValue!: string;

  memberships: any;

  
  constructor(private service : MembershipService) { }

  ngOnInit(): void {
    this.getAllMemberships();
  }

  getAllMemberships() : void{
    this.service.getAllMemberships().subscribe(data=>{
      this.memberships = data;
    })
    
  }

  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }

}
