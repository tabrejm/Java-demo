import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss']
})
export class CardsComponent implements OnInit {

  cards = [
    {
      name : "Football",
      image : "https://images.indianexpress.com/2020/04/aiff-football-1200.jpg",
      description : "Football is the most popular sport in our club"
    },
    {
      name : "Cricket",
      image : "https://images.indianexpress.com/2018/12/india-vs-australia-7597.jpg",
      description : "Cricket is the most popular sport in our club"
    },
    {
      name : "Basketball",
      image : "https://cdnuploads.aa.com.tr/uploads/Contents/2021/02/02/thumbs_b_c_ad7a07e8a1a50739266fbbbf7ae06a0f.jpg?v=165758",
      description : "Basketball is the most popular sport in our club"
    },
    {
      name : "Badminton",
      image : "https://cdn.shopify.com/s/files/1/2183/6715/files/badminton-grass-racket-115016_800x.jpg?v=1556705907",
      description : "Badminton is the most popular sport in our club"
    },
    {
      name : "Baseball",
      image : "https://cdn.britannica.com/q:60/53/212553-050-E4A98496/Baseball-bat.jpg",
      description : "Badminton is the most popular sport in our club"
    },
    {
      name : "Tennis",
      image : "https://media.gettyimages.com/photos/closeup-of-black-modern-rackets-with-light-green-ball-lying-on-tennis-picture-id1184203343?s=612x612",
      description : "Badminton is the most popular sport in our club"
    },
    
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
