import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  sideBarOpen = true;

  users: User = new User;
  id:any = 0;

  constructor(private userService : UserService, private route : ActivatedRoute) { }

  ngOnInit(): void {

    this.id = sessionStorage.getItem("userId");
    console.log(this.id);
    this.userService.getUserById(this.id).subscribe(data => {
      console.log(data);
      this.users = data;
    }, error=>console.log(error));
    
  }


  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }

}
