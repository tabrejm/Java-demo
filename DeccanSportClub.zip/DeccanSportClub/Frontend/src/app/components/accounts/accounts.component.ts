import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UserService } from 'src/app/service/user.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AccountDialogComponent } from '../account-dialog/account-dialog.component';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {

  searchBy:string=""
  accounts:any
  constructor(private userService:UserService, public dialog: MatDialog) { }

  ngOnInit(): void {

    this.userService.getOnlyUsers().subscribe(
      data => 
      {
        console.log(data)
        this.accounts=data;

      }
    )

  }

  openDialog(id:any) {
    sessionStorage.setItem("accountId",id);
    const dialogRef = this.dialog.open(AccountDialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


  sendInformation()
  {

  }


}
