import { Component, OnInit } from '@angular/core';
import { Batches } from 'src/app/models/batches';
import { Enrollment } from 'src/app/models/enrollments';
import { BatchService } from 'src/app/service/batch.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-batches',
  templateUrl: './batches.component.html',
  styleUrls: ['./batches.component.scss']
})
export class BatchesComponent implements OnInit {

  batches : Batches[] = [];


  id:number=0;
  userId:any

  sideBarOpen = true;
  constructor(private batchService : BatchService, private enrollService : UserService) { }

  ngOnInit(): void {
    this.getBatches();
    this.enrollService.getAllEnrollments().subscribe(
      data => 
      {
        this.id=data.length + 1
      }
    )
    this.userId=sessionStorage.getItem("userId")
  }

  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }

  public getBatches() : void {
    this.batchService.getBatches().subscribe(
      data=>{
        this.batches = data;
      }
    ); 
  }

  enroll() {

    let enrollment:Enrollment ={
   
      approveRequest : false
    }
          
    this.enrollService.addEnrollment(this.userId,enrollment).subscribe(
      data =>{
        console.log(data);
        alert("Enrolled successfully");
      }
    )

  }

  

}
