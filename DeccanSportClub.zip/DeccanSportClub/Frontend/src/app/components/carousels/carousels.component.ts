import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-carousels',
  templateUrl: './carousels.component.html',
  styleUrls: ['./carousels.component.scss']
})
export class CarouselsComponent implements OnInit {
  image = [
    "http://c.min.ms/m/b/60/60170/af787ba6.jpg",
    "https://ipl.ae/wp-content/uploads/2021/02/india-cricket.jpg",
    "https://cdn.wallpapersafari.com/4/91/Tki1CU.jpg"

  ];

  constructor() {
   
   }

  ngOnInit(): void {
  }

}
