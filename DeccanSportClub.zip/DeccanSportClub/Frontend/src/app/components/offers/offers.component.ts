import { Component, OnInit } from '@angular/core';
import { Offers } from 'src/app/models/offers';
import {MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CommentsComponent } from '../comments/comments.component';
import { UserService } from 'src/app/service/user.service';


@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.scss']
})
export class OffersComponent implements OnInit {
  sideBarOpen = true;

  

  offers : Offers[] = [];

  constructor(private dialog : MatDialog,private service : UserService) { }

  ngOnInit(): void {
    this.getAllOffers();
  }

  getAllOffers() {
    this.service.getAllOffers().subscribe(
      data=>{
        this.offers = data;
      }
    )

  }

  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }

  likeButton() :void {
    for(let i in this.offers) {
      this.offers[i].likes ++;
    }
  }

  comment() {
    this.dialog.open(CommentsComponent);
  }

}
