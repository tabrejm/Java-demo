import { Component, OnInit } from '@angular/core';
import { Batches } from 'src/app/models/batches';
import { Router } from '@angular/router';
import { BatchService } from 'src/app/service/batch.service';
import { MatMomentDateModule } from '@angular/material-moment-adapter';

@Component({
  selector: 'app-create-batch',
  templateUrl: './create-batch.component.html',
  styleUrls: ['./create-batch.component.scss']
})
export class CreateBatchComponent implements OnInit {


  minDate: Date = new Date();
  //maxDate: Date = new Date();

  mininumDate: MatMomentDateModule = new MatMomentDateModule;
  //maxinumDate: MatMomentDateModule = new MatMomentDateModule;
  

  batches : Batches = new Batches();

  constructor(
    private batchService : BatchService, 
    private router : Router,
    
    ) { }

  ngOnInit(): void {
  }

  saveBatch() {
    this.batchService.addBatch(this.batches).subscribe(data => {
      console.log(data);
      this.goToBatchList();
    },
    error => console.log(error));
  }

  goToBatchList() {
    this.router.navigate(['/manager']);
  }

  onSubmit() {
    console.log(this.batches);
    this.saveBatch();

  }

}
