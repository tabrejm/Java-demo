package com.cybage.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.UserNotFoundexception;
import com.cybage.models.Enrollments;

import com.cybage.models.Sport;
import com.cybage.models.User;
import com.cybage.repository.EnrollmentsRepository;

import com.cybage.repository.SportRepository;
import com.cybage.repository.UserRepository;


@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private EnrollmentsRepository enrollmentRepository;
	
	@Autowired
	private SportRepository sportRepository;
	

	public User addUser(User user) {
		return userRepository.save(user);
	}

	public List<User> findAllUsers() {
		return userRepository.findAll();
	}

	public User updateUser(User user) {
		return userRepository.save(user);
	}

	public User findUserById(int id) {
		return userRepository.findById(id)
				.orElseThrow(() -> new UserNotFoundexception("User by id :" + id + " was not found!"));
	}

	public void deleteUser(int id) {
		userRepository.deleteById(id);
	}
	
	public User findByEmail(String email) {
		return userRepository.findByemail(email);
		
	}
	
	public User findByName(String name) {
		return userRepository.findByname(name);
		
	}

	public User findByUsername(String username) {
		return userRepository.findByusername(username);
		
	}

	/*
	public List<User> getAllEnrollment(boolean status){
		return userRepository.getAllEnrollment(status);
	}*/
	
	public List<Enrollments> getAllEnrollments() {
		return enrollmentRepository.findAll();
	}
	
	public Enrollments addEnrollment(int userId,Enrollments enrollment) {
		User user=userRepository.getById(userId);
		user.addEnrollment(enrollment);
		Enrollments savedEnrollment=enrollmentRepository.save(enrollment);
		return savedEnrollment;
	}
	
	

	public String updateEnrollmentStatus(int userId, String status) {
		Enrollments e = enrollmentRepository.updateEnrollmentStatus(userId);
		boolean sts = false;
		if(status.equalsIgnoreCase("approve"))
			sts = true;
		e.setApproveRequest(sts);
		
		if(e != null)
			return "updated Enrollment Status with "+status+"d";
		else
			return "Not updated";
	}
	
	public Enrollments updateEnrollment(int userId,Enrollments enrollment)
	{
		User user=userRepository.getById(userId);
		user.addEnrollment(enrollment);
		return enrollmentRepository.save(enrollment);
	}

	public List<Sport> fetchAllSports() {
		return sportRepository.findAll();
	}
	
	
}
