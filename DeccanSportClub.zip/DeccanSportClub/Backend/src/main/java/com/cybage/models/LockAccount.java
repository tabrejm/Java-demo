package com.cybage.models;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="lock_accounts")
public class LockAccount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int lockAccountId;
	
	@Column(name="account_email",unique=true)
	private String email;
	
	@Column(name="locked_date")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date lockedDate;
	
	public LockAccount() {
		// TODO Auto-generated constructor stub
	}

	public LockAccount(String email, Date lockedDate) {
		super();
		this.email = email;
		this.lockedDate = lockedDate;
	}

	public int getLockAccountId() {
		return lockAccountId;
	}

	public void setLockAccountId(int lockAccountId) {
		this.lockAccountId = lockAccountId;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getLockedDate() {
		return lockedDate;
	}

	public void setLockedDate(Date lockedDate) {
		this.lockedDate = lockedDate;
	}
	
	
	

}
