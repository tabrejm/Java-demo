package com.cybage.controller;


import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cybage.models.Enrollments;
import com.cybage.models.Sport;
import com.cybage.models.User;

import com.cybage.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	
	//private static final Logger logger = LogManager.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;

	
	
	
	@GetMapping("/all")
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.findAllUsers();
		//logger.debug("Fetched all users from controller");
		return new ResponseEntity<List<User>>(users, HttpStatus.OK); 
	}
	
	@GetMapping("/fetchUsers")
	public ResponseEntity<List<User>> fetchAllUsers() {
		List<User> users = userService.findAllUsers();
		List<User> onlyUsers = new ArrayList<User>();
		
		for (User user : users) {
			
			if(user.getRole().equalsIgnoreCase("USER"))
			{
				onlyUsers.add(user);
			}
		}
	
		
		//logger.debug("Fetched all users from controller");
		return new ResponseEntity<List<User>>(onlyUsers, HttpStatus.OK); 
	}
	
	@GetMapping("/find/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") int id) {
		User user = userService.findUserById(id);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	
	@GetMapping("/find_name/{name}")
	public ResponseEntity<User> getUserByName(@PathVariable("name") String name) {
		User findByName = userService.findByName(name);
		return new ResponseEntity<User>(findByName, HttpStatus.OK);
	}
	
	@GetMapping("/find_email/{email}")
	public ResponseEntity<User> getUserByEmail(@PathVariable("email") String email) {
		User findByEmail = userService.findByEmail(email);
		return new ResponseEntity<User>(findByEmail, HttpStatus.OK);
	}
	
	@GetMapping("/find_username/{username}")
	public ResponseEntity<User> getUserByUsername(@PathVariable("username") String username) {
		User findByUsername = userService.findByUsername(username);
		return new ResponseEntity<User>(findByUsername, HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<User> addUser(@RequestBody User user) {
		User newUser = userService.addUser(user);
		return new ResponseEntity<User>(newUser, HttpStatus.CREATED);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<User> updateUser(@PathVariable int id, @RequestBody User userDetails) {
		User user = userService.findUserById(id);
		
		user.setName(userDetails.getName());
		user.setEmail(userDetails.getEmail());
		user.setPassword(userDetails.getPassword());
		user.setUsername(userDetails.getUsername());
		user.setMobileNumber(userDetails.getMobileNumber());
		user.setRegistrationDate(userDetails.getRegistrationDate());
		user.setAddress(userDetails.getAddress());
		user.setGender(userDetails.getGender());
		
		User updatedUser = userService.addUser(user);
		return new ResponseEntity<User>(updatedUser, HttpStatus.CREATED);
	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable("id") int id) {
		userService.deleteUser(id);
		return new ResponseEntity<User>(HttpStatus.OK);
	}

	/*
	@GetMapping("/enrollment/approved")
	public ResponseEntity<List<User>> getAllApprovedEnrollment() {
		List<User> users = userService.getAllEnrollment(true);
		return new ResponseEntity<List<User>>(users, HttpStatus.OK); 
	}*/
	
	@GetMapping("/enrollments")
	public ResponseEntity<List<Enrollments>> getaAllEnrollments() {
		List<Enrollments> enrollments = userService.getAllEnrollments();
		return new ResponseEntity<List<Enrollments>>(enrollments, HttpStatus.OK); 
	}
	
	@PostMapping("/addEnrollment/{id}")
	public ResponseEntity<Enrollments> addEnrollments(@PathVariable int id,@RequestBody Enrollments enrollment) {
		Enrollments newEnrollment = userService.addEnrollment(id,enrollment);
		return new ResponseEntity<Enrollments>(newEnrollment, HttpStatus.CREATED);
	} 
	
	/*
	@GetMapping("/enrollment/rejected")
	public ResponseEntity<List<User>> getAllRejectedEnrollment() {
		List<User> users = userService.getAllEnrollment(false);
		return new ResponseEntity<List<User>>(users, HttpStatus.OK); 
	}*/

	//status coming from FrontEnd Approve/Reject
	@PutMapping("/enrollment/{userId}/{status}")
	public ResponseEntity<String> getUpdateEnrollmentStatus(@PathVariable int userId, @PathVariable String status) {
		String msg = userService.updateEnrollmentStatus(userId, status);
		return new ResponseEntity<String>(msg, HttpStatus.OK); 
	}
	
	@PutMapping("/enrollment/update/{userId}")
	public ResponseEntity<?> UpdateEnrollment(@PathVariable int userId,@RequestBody Enrollments enrollment) {
		Enrollments updatedEnrollment = userService.updateEnrollment(userId,enrollment);
		return new ResponseEntity<Enrollments>(updatedEnrollment, HttpStatus.OK); 
	}

	@GetMapping("/sportList")
	public ResponseEntity<List<Sport>> fetchAllSports() {
		List<Sport> sports = userService.fetchAllSports();
		return new ResponseEntity<List<Sport>>(sports, HttpStatus.OK); 
	}
	
	
	

	
}
