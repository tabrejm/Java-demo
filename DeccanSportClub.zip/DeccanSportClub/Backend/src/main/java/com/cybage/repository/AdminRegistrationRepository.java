package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.models.Manager;
import com.cybage.models.User;

@Repository
public interface AdminRegistrationRepository extends JpaRepository<User, Long>{

	public Manager findByEmail(String email);

	public Manager findByEmailAndPassword(String email, String password);

	public Manager save(Manager manager);

}
