package com.cybage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMajorProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaMajorProjectApplication.class, args);
	}

}
