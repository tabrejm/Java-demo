package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.models.Manager;
import com.cybage.repository.AdminRegistrationRepository;



@Service
public class AdminRegistrationService {
	
	@Autowired
	private AdminRegistrationRepository registrationRepository;
	
	public Manager saveManager(Manager manager) {
		return registrationRepository.save(manager);
	}
	
	public Manager fetchManagerByEmail(String email) {
		return registrationRepository.findByEmail(email);
	}
	
	public Manager fetchManagerByEmailAndPassword(String email, String password) {
		return registrationRepository.findByEmailAndPassword(email, password);
	}

}
