package com.cybage.controller;

import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.models.AccountEmail;
import com.cybage.models.Email;
import com.cybage.models.User;
import com.cybage.service.UserService;

@RestController
@RequestMapping("/send")
@CrossOrigin(origins = "http://localhost:4200")
public class EmailController {
	
	@Autowired
    private JavaMailSender javaMailSender;
	
	@Autowired
	private Properties emailPorperties;

	@Autowired
	private UserService userService;
	
	@PostConstruct
	public void init()
	{
		System.out.println("In init"+javaMailSender);
	}
	
	@PostMapping("/{id}")
	public ResponseEntity<?> sendAccountInformation(@PathVariable int id,@RequestBody AccountEmail accountEmail)
	{
	   
		SimpleMailMessage message=new SimpleMailMessage();
		System.out.println(accountEmail.getEmail());
		String content=userService.findUserById(id).toString();
		User manager=userService.findByEmail(accountEmail.getEmail());
		System.out.println(manager);
		if(manager!=null)
		{
			message.setTo(accountEmail.getEmail());
			message.setSubject("User Account Information");
			message.setText(content);
			javaMailSender.send(message);
			return new ResponseEntity<>(accountEmail,HttpStatus.OK);
		}
		else
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			
	}

}
