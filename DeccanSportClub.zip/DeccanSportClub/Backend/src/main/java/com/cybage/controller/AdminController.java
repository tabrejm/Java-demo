package com.cybage.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.models.Manager;

import com.cybage.service.AdminRegistrationService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminRegistrationService adminregistrationService;
	
	@PostMapping("/registerManager")
	public Manager registerManager(@RequestBody Manager manager) throws Exception {
		
		String tempEmailId = manager.getEmail();
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			Manager userEmail = adminregistrationService.fetchManagerByEmail(tempEmailId);
			if(userEmail != null) {
				throw new Exception("User with "+tempEmailId+" already exists!");
			}
		}
		Manager saveManager = adminregistrationService.saveManager(manager);
		return saveManager;
	}
	
	@PostMapping("/loginManager")
	public Manager loginManager(@RequestBody Manager manager) throws Exception {
		
		String tempEmail = manager.getEmail();
		String tempPassword = manager.getPassword();
		Manager managerObject = null;
		
		if(tempEmail !=null && tempPassword != null) {
			managerObject = adminregistrationService.fetchManagerByEmailAndPassword(tempEmail, tempPassword);
		}
		if(managerObject == null) {
			throw new Exception("Bad crenditials!");
		}
		return managerObject;
	}

}
