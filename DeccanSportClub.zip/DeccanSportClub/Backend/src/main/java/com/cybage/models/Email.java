package com.cybage.models;

public class Email {
	
	private String destinationEmail;
	private String message;
	private String subject;
	
	public Email() {
		
	}

	public Email(String destinationEmail, String message, String subject) {
		super();
		this.destinationEmail = destinationEmail;
		this.message = message;
		this.subject = subject;
	}

	public String getDestinationEmail() {
		return destinationEmail;
	}

	public void setDestinationEmail(String destinationEmail) {
		this.destinationEmail = destinationEmail;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "Email [destinationEmail=" + destinationEmail + ", message=" + message + ", subject=" + subject + "]";
	}
	
	
	

}
