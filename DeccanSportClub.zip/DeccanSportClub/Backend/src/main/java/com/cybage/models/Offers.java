package com.cybage.models;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Offers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable = false, updatable = false)
	private Long id;
	
	private String offerName;
	
	private Integer likes;
	
	@OneToMany(mappedBy = "offer")
	private List<Comments> comment = new ArrayList<Comments>();
	
	public Offers() {
		// TODO Auto-generated constructor stub
	}

	public Offers(String offerName, Integer likes, ArrayList<Comments> comment) {
		super();
		this.offerName = offerName;
		this.likes = likes;
		this.comment = comment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public Integer getLikes() {
		return likes;
	}

	public void setLikes(Integer likes) {
		this.likes = likes;
	}

	public List<Comments> getComment() {
		return comment;
	}

	public void setComment(ArrayList<Comments> comment) {
		this.comment = comment;
	}
	
	

	

	
}
