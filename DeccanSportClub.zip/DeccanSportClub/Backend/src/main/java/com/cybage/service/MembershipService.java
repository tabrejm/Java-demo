package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.UserNotFoundexception;
import com.cybage.models.Membership;
import com.cybage.models.MembershipType;
import com.cybage.repository.MembershipRepository;


@Service
public class MembershipService {
	
	private MembershipRepository membershipRepository;
	
	@Autowired
	public MembershipService(MembershipRepository membershipRepository) {
		this.membershipRepository = membershipRepository;
	}
	
	public List<Membership> findAllMemberships() {
		return membershipRepository.findAll();
	}
	
	public Membership findByType(MembershipType membershipType) {
		return membershipRepository.findByMembershipType(membershipType);
	}
	
	public Membership findMembershipById(Long id) {
		return membershipRepository.findById(id)
				.orElseThrow(() -> new UserNotFoundexception("User by id :" + id + " was not found!"));
	}

}
