package com.cybage.models;

public enum RoleType {
	
	USER,ADMIN,MANAGER

}
