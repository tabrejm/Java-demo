package com.cybage.models;

public class SendOtp {

	private String email;
	
	public SendOtp() {
		// TODO Auto-generated constructor stub
	}

	public SendOtp(String email) {
		super();
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
