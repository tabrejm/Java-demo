package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.models.LockAccount;

@Repository
public interface LockedAccountRepository extends JpaRepository<LockAccount, Integer> {
	
	LockAccount findByemail(String email);

}
