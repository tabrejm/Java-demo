package com.cybage.exception;

public class UserNotFoundexception extends RuntimeException{
	
	public UserNotFoundexception(String message) {
		super(message);
	}

}
