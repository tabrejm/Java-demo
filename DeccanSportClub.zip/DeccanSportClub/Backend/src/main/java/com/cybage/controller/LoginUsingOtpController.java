package com.cybage.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.models.LoginOtp;
import com.cybage.models.SendOtp;
import com.cybage.models.User;
import com.cybage.service.RegistrationService;
import com.cybage.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class LoginUsingOtpController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RegistrationService registrationService;
	
	@Autowired
	private JavaMailSender sender;
	
	
	@PostMapping("/send_otp")
	public ResponseEntity<?> sendOtp(@RequestBody SendOtp otp)
	{
		User user=userService.findByEmail(otp.getEmail());
		if(user==null)
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		else
		{
			SimpleMailMessage message=new SimpleMailMessage();
			  Random rnd = new Random();
			    int number = rnd.nextInt(999999);
			    String otp_number= String.format("%06d", number);
					message.setTo(otp.getEmail());
					message.setSubject("Login otp");
				    message.setText("OTP = "+otp_number);
				    sender.send(message);
					return new ResponseEntity<>(otp_number,HttpStatus.OK);

		}
	}
	
	@PostMapping("/login_using_otp")
	public ResponseEntity<?> loginUsingOtp(@RequestBody SendOtp loginOtp,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else
		{
			String email = loginOtp.getEmail();
			User userObject = null;
			
			userObject = userService.findByEmail(email);

			if(result.hasErrors() || userObject==null)
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			else
				return new ResponseEntity<User>(userObject,HttpStatus.OK);
		}
		
		
	}

}
