package com.cybage.models;

public enum MembershipType {
	SILVER, GOLD, PLATINUM

}
