import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Membership } from '../models/membership';

@Injectable({
  providedIn: 'root'
})
export class MembershipService {

  private apiServelUrl = environment.apiBaseUrl+'/membership';

  constructor(private http : HttpClient) { }

  //getAllMemberships
  public getAllMemberships() : Observable<Membership[]> {
    return this.http.get<Membership[]>(`${this.apiServelUrl}/find`);
  }
}
