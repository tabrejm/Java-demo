export class RequestRegistration {
    private name : string = "";
    private email : string = "";
    private password : string = "";
    private userName : string = "";
    private registrationDate : string = "";
    private mobileNumber : string = "";
    private address : string = "";
    private gender : string = "";


    public setName(p_name : string) {
        this.name = p_name;
    }

    public getName() : string {
        return this.name ;
    }

    public setEmail(p_email : string) {
        this.email = p_email;
    }

    public getEmail() : string {
        return this.email;
    }

    public setPassword(p_password : string) {
        this.password = p_password;
    }

    public getPassword() : string {
        return this.password;
    }

    public setUserName(p_userName : string) {
        this.userName = p_userName;
    }

    public getUserName() : string {
        return this.userName;
    }

    public setRegistrationDate(p_registrationDate : string) {
        this.registrationDate = p_registrationDate;
    }

    public getRegistrationDate() : string {
        return this.registrationDate;
    }

    public setMobileNumber(p_MobileNumber : string) {
        this.mobileNumber = p_MobileNumber;
    }

    public getMobileNumber() : string {
        return this.mobileNumber;
    }

    public setAddress(p_Address : string) {
        this.address = p_Address;
    }

    public getAddress() : string {
        return this.address;
    }

    public setGender(p_gender : string) {
        this.gender = p_gender;
    }

    public getGender() : string {
        return this.gender;
    }
}