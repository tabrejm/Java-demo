export class Offers {
   Id! : number;
   offerName : string = "";
   likes! : number;
   comments : string[] = [];
}