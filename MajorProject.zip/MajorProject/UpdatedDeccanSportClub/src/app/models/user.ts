export class User {
    id! : number;
    name : string = "";
    email : string = "";
    password : string = "";
    username : string = "";
    role : string = "";
    registrationDate : Date = new Date();
    mobileNumber : string = "";
    address : string = "";
    gender : string = "";
    

    
} 