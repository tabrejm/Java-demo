import { MembershipType } from "./memberType";

export class Membership  {
    id! : number;
    membershipType: MembershipType = 0;
    
}