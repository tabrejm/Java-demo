export interface LockAccount
{
    email:string,
    lockedDate:Date

}