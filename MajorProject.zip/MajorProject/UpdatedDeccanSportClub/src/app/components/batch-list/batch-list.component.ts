import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Batches } from 'src/app/models/batches';
import { User } from 'src/app/models/user';
import { BatchService } from 'src/app/service/batch.service';
import { UserService } from 'src/app/service/user.service';
import {MatTableDataSource} from '@angular/material/table';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-batch-list',
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.scss']
})
export class BatchListComponent implements OnInit {

  sideBarOpen = true;

  batches : Batches[] = [];

  displayedColumns : string[] = ['Id','BatchName','startDate','endDate','time','imageUrl','actions'];

  users : User[] = [];

  status : boolean = false;

  displayedColumns1 : string[] = ['Id','name','email','status'];

  constructor(private batchService : BatchService,private userService : UserService, private router : Router) { }

  ngOnInit(): void {
    this.getBatches();
    this.getUsers();
  }

  sideBarToggler() {
    this.sideBarOpen = !this.sideBarOpen;
  }
  

  public getBatches() : void {
    this.batchService.getBatches().subscribe(
      data=>{
        this.batches = data;
      }
    ); 
  }

  public getEnrollmentStatus() : boolean {
    this.userService.getEnrollmentStatus().subscribe(
      data=>{
        this.status = false;
      }
    )
    return false;
  }

  public getUsers() : void {
    this.userService.getUsers() .subscribe(
      data=>{
        this.users = data;
      }
    ); 
  }

  onCreate() {

  }

  addData() {
    this.router.navigate(['create-batch']);
  }

  updateBatch(id : number) {
    this.router.navigate(['updateBatch',id]);
  }

  deleteBatch(id : number) {
    this.batchService.deleteBatch(id).subscribe(data=>{
      console.log(data);
      this.getBatches();
    },error=>console.log(error));
  }

  batchDetails(id : number) {
    this.router.navigate(['batchDetails',id]);


  }

}
