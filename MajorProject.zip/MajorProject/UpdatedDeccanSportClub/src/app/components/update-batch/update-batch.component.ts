import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Batches } from 'src/app/models/batches';
import { BatchService } from 'src/app/service/batch.service';


@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.scss']
})
export class UpdateBatchComponent implements OnInit {

  

  id! : number;

  batches : Batches = new Batches();

  constructor(private batchService : BatchService, private route : ActivatedRoute, private router : Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.batchService.getBatchById(this.id).subscribe(data => {
      console.log(data);
      this.batches = data;
    }, error=>console.log(error));
  }

  /*
  updateBatch() {
    this.batchService.updateBatch(this.id, this.batches).subscribe(data => {
      console.log(data);
      this.batches = new Batches();
      this.goToBatchList();
    },error=>console.log(error))
  }*/

  goToBatchList() {
    this.router.navigate(['/manager']);
  }

  onSubmit() {
    console.log(this.batches);
    this.batchService.updateBatch(this.id, this.batches).subscribe(data=>{
      this.goToBatchList();

    },error=>console.log(error));

  }

}
