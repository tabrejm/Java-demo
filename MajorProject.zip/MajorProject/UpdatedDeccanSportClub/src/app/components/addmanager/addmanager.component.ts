
import { Component, OnInit } from '@angular/core';
import { Validators, FormControl } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-addmanager',
  templateUrl: './addmanager.component.html',
  styleUrls: ['./addmanager.component.scss']
})
export class AddmanagerComponent implements OnInit {

  user: User = new User();

  minDate : Date = new Date();
  maxDate : Date = new Date();

  mininumDate : MatMomentDateModule = new MatMomentDateModule;
  maxinumDate : MatMomentDateModule = new MatMomentDateModule;

  hide = true;
  
  id: number = 0;
  name = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required, Validators.minLength(5)]);
  username = new FormControl('', [Validators.required, Validators.minLength(4)]);
  registrationDate = new FormControl('', Validators.required);
  mobileNumber = new FormControl('', Validators.required);
  address = new FormControl('', Validators.required);
  gender = new FormControl('', [Validators.required]);

  constructor(
    private authenticationService: AuthenticationService,
    private userService: UserService,
    private router: Router
  ) {
    // Set minimum to Jan 1st 20 years in past and Dec 31 a year ing future
    /*
    const currentYear = new Date().getFullYear();
    this.minDate = new Date(currentYear - 0, 0 ,1);
    this.maxDate = new Date(currentYear + 1,11,31);*/
   }

  ngOnInit(): void {
    this.userService.getUsers().subscribe(data => {
      this.id = data.length + 1;
    })
  }

  register() {

    let registeredUser: User = {

      id: this.id,
      name: this.name.value,
      email: this.email.value,
      password: this.password.value,
      username: this.username.value,
      registrationDate: this.registrationDate.value,
      role : "MANAGER",
      mobileNumber: this.mobileNumber.value,
      address: this.address.value,
      gender: this.gender.value

    }
    this.authenticationService.registerUser(registeredUser).subscribe(data => {
      console.log(data);
    });
    this.router.navigate(['login']);

  }
 
  getErrorMessage() {
    if(this.email.hasError('required')) {
      return 'You must enter a value';
    }
    return this.email.hasError('email') ? 'Not a valid email!' : '';
  }

  getNameErrorMessage() {
    if(this.username.hasError('required')) {
      return 'Name is required!';
    }
    return this.username.hasError('username') ? 'Not a valid name!' : '';

  }

  getMobileErrorMessage() {
    if(this.mobileNumber.hasError('required')) {
      return 'You must enter a mobile number';
    }
    return this.mobileNumber.hasError('mobileNumber') ? 'Not a valid mobile number' : '';
  }

  getGenderErrorMessage() {
    if(this.gender.hasError('required')) {
      return 'You must select!';
    }
    return this.gender.hasError('gender') ? 'Not a valid gender':'';
  }

 

  
 

}
