import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ISport } from 'src/app/models/sport';
import { SportService } from 'src/app/service/sport.service';

@Component({
  selector: 'app-add-sport',
  templateUrl: './add-sport.component.html',
  styleUrls: ['./add-sport.component.scss']
})
export class AddSportComponent implements OnInit {

 
  message:any;
  id:number=0;
  sportname= new FormControl('',[Validators.required, Validators.maxLength(10), Validators.minLength(3)])

constructor(private sportService:SportService, private _router:Router) { }

ngOnInit(): void {
   
  this.sportService.getAllSports().subscribe(data=>
    {
      console.log(data.length);
     this.id=data.length+1;
    }
  )

}



add(sportname:string)
{
  console.log(sportname);
  
  
  console.log(this.id);

  let sport:ISport={
    sport_id:this.id,
    sport_name: sportname

     //sport_id:this.id,
      //sport_name:sportname
  };
 
  
 this.sportService.addSport(sport).subscribe(
    data=>{
           this.message=data;
    }
  );

   alert(sport.sport_name+ " added");
  
  this._router.navigateByUrl("/View_Sports");

}
}
