import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit {

  count : number = 0;
  constructor(private router : Router) { }

  ngOnInit(): void {
    if (! localStorage.justOnce) {
      localStorage.setItem("justOnce", "true");
      window.location.reload();
  }
    
  }

  load() {
    window.onload = function () {
      if (! localStorage.justOnce) {
          localStorage.setItem("justOnce", "true");
          window.location.reload();
      }
  }

  }

}
