import { Component, OnInit } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { AdminService } from 'src/app/service/admin.service';
import { BatchService } from 'src/app/service/batch.service';
import { SportService } from 'src/app/service/sport.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-generate-reports',
  templateUrl: './generate-reports.component.html',
  styleUrls: ['./generate-reports.component.scss']
})
export class GenerateReportsComponent implements OnInit {

  constructor(private adminService:AdminService,private sportService:SportService,private userService : UserService,private batchService : BatchService) { }

  enrollments:any;
  batches:any;
  sports:any;

  ngOnInit(): void {
   
   this.userService.getAllEnrollments().subscribe(
      data =>{
        this.enrollments=data
      }
    );
    this.batches=this.batchService.getBatches().subscribe(
      data =>{
        this.batches=data
      }
    );;
    this.sports=this.sportService.getAllSports().subscribe(
      data =>{
        this.sports=data
      }
    );;
  }

  generateSportPdf()
  {
     let data=document.getElementById("sports") as HTMLElement
  
     html2canvas(data).then(canvas => {
    
      let fileWidth = 208;
      let fileHeight = canvas.height * fileWidth / canvas.width;
      
      const FILEURI = canvas.toDataURL('image/png')
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight)
      
      PDF.save('sports-report.pdf');
  });     
  }

  generateEnrollmentPdf()
  {
     let data=document.getElementById("enrollments") as HTMLElement
  
     html2canvas(data).then(canvas => {
    
      let fileWidth = 208;
      let fileHeight = canvas.height * fileWidth / canvas.width;
      
      const FILEURI = canvas.toDataURL('image/png')
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight)
      
      PDF.save('enrollments-report.pdf');
  });     
  }

  generateBatchesPdf()
  {
     let data=document.getElementById("batches") as HTMLElement
  
     html2canvas(data).then(canvas => {
    
      let fileWidth = 208;
      let fileHeight = canvas.height * fileWidth / canvas.width;
      
      const FILEURI = canvas.toDataURL('image/png')
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight)
      
      PDF.save('batches-report.pdf');
  });     
  }
}
