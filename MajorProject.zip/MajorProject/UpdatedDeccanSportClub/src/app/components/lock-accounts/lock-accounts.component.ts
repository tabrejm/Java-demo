import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LockAccountServiceService } from 'src/app/service/lock-account-service.service';

@Component({
  selector: 'app-lock-accounts',
  templateUrl: './lock-accounts.component.html',
  styleUrls: ['./lock-accounts.component.scss']
})
export class LockAccountsComponent implements OnInit {


  lockAccounts:any
  searchBy:string=""

  constructor(private router : Router,private lockAccountService:LockAccountServiceService ) { }

  ngOnInit(): void {

    this.lockAccountService.getAllLockedAccounts().subscribe(
      data => {
        this.lockAccounts=data;
      }
    );
    
  }

  unlockAccount(id:number)
  {
    this.lockAccountService.deletelockedAccount(id).subscribe(
      data=>{
          alert(data);
            this.router.navigate(['/Lock_Accounts'])
        .then(() => {
          window.location.reload();
        });
      }

    );
    
  }


}
