import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { SportService } from 'src/app/service/sport.service';


const THUMBUP_ICON =
  `
  <svg class="svg-icon search-icon" aria-labelledby="title desc" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.9 19.7"><title id="title">Search Icon</title><desc id="desc">A magnifying glass icon.</desc><g class="search-path" fill="none" stroke="#848F91"><path stroke-linecap="square" d="M18.5 18.3l-5.4-5.4"/><circle cx="8" cy="8" r="7"/></g></svg>
`;



@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.scss']
})
export class SportsComponent implements OnInit {

  searchBy:string="";
  sports:any;
  message:String="";

 
  constructor(private sports_service:SportService, private _router:Router,iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
  
    iconRegistry.addSvgIconLiteral('search', sanitizer.bypassSecurityTrustHtml(THUMBUP_ICON));

   }


  ngOnInit(): void {

    this.sports_service.getAllSports().subscribe(
      data => {
        this.sports=data
    });
  }

  removeSport(sportId:number)
  {
    this.sports_service.deleteSport(sportId).subscribe();
    this._router.navigate(['/View_Sports'])
    .then(() => {
      window.location.reload();
    });
  }

}
