import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ISport } from 'src/app/models/sport';
import { SportService } from 'src/app/service/sport.service';

@Component({
  selector: 'app-update-sport',
  templateUrl: './update-sport.component.html',
  styleUrls: ['./update-sport.component.scss']
})
export class UpdateSportComponent implements OnInit {

  sportid=new FormControl();
  sportname=new FormControl('',[Validators.required, Validators.maxLength(10) ,Validators.minLength(3)])

  constructor(private sportService:SportService,private router:Router,private _activatedRoute:ActivatedRoute) { }
 
  sport_id:number=0;
  sportName:string="";
  sports:any;
  sport!:ISport;
  message:string="";


  ngOnInit(): void {

    this.sport_id=this._activatedRoute.snapshot.params.id;
    console.log(this._activatedRoute.snapshot.params.id);
    
    this.sportService.searchSport(this.sport_id).subscribe(
      data => {
        this.sportname.setValue(data.sport_name);
      }, error=>{console.log(error)
           
      }
    )
  
  }



  editSport(name:string)
  {
    let sport:ISport={
      sport_id:this.sport_id,
      sport_name:name

    }
    console.log(sport);
    
       this.sportService.updateSport(sport).subscribe();

        alert("Sport "+this.message+" updated successfully")
      
       this.router.navigateByUrl("/View_Sports");


  }


}
