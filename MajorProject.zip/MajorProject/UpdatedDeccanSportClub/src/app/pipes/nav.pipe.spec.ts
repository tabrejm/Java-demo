import { NavPipe } from './nav.pipe';

describe('NavPipe', () => {
  it('create an instance', () => {
    const pipe = new NavPipe();
    expect(pipe).toBeTruthy();
  });
});
