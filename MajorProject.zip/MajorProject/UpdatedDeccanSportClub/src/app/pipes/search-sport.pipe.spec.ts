import { SearchSportPipe } from './search-sport.pipe';

describe('SearchSportPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchSportPipe();
    expect(pipe).toBeTruthy();
  });
});
