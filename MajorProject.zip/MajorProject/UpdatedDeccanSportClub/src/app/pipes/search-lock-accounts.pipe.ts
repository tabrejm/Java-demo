import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchLockAccounts'
})
export class SearchLockAccountsPipe implements PipeTransform {

  transform(value: any[], args: string): any {
    if(!value) return null;
    if(!args) return value;
    
    let search=args.toLowerCase();
    return value.filter(lockAccount => { 
      let lockAccountEmail=lockAccount.email.toLowerCase(); 
      return lockAccountEmail.indexOf(search) !== -1;});
  }

}
