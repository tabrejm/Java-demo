import { SearchAccountPipe } from './search-account.pipe';

describe('SearchAccountPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchAccountPipe();
    expect(pipe).toBeTruthy();
  });
});
