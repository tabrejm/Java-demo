package com.cybage.models;

import javax.persistence.*;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Sport")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Sport {
	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="sport_id") 
	 
	 private int sport_id;
	 
	 @Column(name="sport_name")
	 private String sport_name; 
	 
	 
	 public Sport() {
		// TODO Auto-generated constructor stub
	}


	public Sport(int sport_id,String sport_name) {
		super();
		this.sport_id = sport_id;
		this.sport_name = sport_name;
	}


	public int getSport_id() {
		return sport_id;
	}


	public void setSport_id(int sport_id) {
		this.sport_id = sport_id;
	}


	public String getSport_name() {
		return sport_name;
	}


	public void setSport_name(String sport_name) {
		this.sport_name = sport_name;
	}


	@Override
	public String toString() {
		return "Sport [sport_id=" + sport_id + ", sport_name=" + sport_name + "]";
	}

	

}
