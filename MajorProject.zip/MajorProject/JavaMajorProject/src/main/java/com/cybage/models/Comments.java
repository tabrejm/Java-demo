package com.cybage.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Comments {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Integer id;
	
	private String message;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	//one user can have many comments(user-cart, items-comments)
	
	@ManyToOne
	@JoinColumn(name = "offer_id")
	@JsonIgnore
	private Offers offer;
	
	public Comments() {
		// TODO Auto-generated constructor stub
	}
	

	public Comments(String message, User user) {
		super();
		this.message = message;
		this.user = user;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

}
