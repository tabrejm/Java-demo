package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.models.LockAccount;
import com.cybage.repository.LockedAccountRepository;

@Service
public class LockedAccountService {
	
	@Autowired
	private LockedAccountRepository lockedAccountRepository;
	
	public List<LockAccount> getAllLockedAccounts()
	{
		return lockedAccountRepository.findAll();
	}
	
	public LockAccount getByLockedAccountById(int lockedAccountId)
	{
		return lockedAccountRepository.getById(lockedAccountId);
	}
	
	public LockAccount getByLockedAccountByEmail(String email)
	{
		return lockedAccountRepository.findByemail(email);
	}
	
	
	public LockAccount addLockedAccount(LockAccount lockedAccount)
	{
		return lockedAccountRepository.save(lockedAccount);
	}
	
	public void deleteLockedAccountById(int lockedAccountId)
	{
		 lockedAccountRepository.deleteById(lockedAccountId);
	}
	
	

}
