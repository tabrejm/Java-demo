package com.cybage.repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.cybage.models.Sports;
import com.cybage.models.*;

public interface AdminRepository extends JpaRepository<User,Integer> {
	
	//User finById(int id) throws SQLException, ClassNotFoundException;
	
	//List<User> getAllUsers() throws SQLException, ClassNotFoundException;
	
	//boolean updateUser(User user) throws SQLException, ClassNotFoundException;
	
	//boolean deleteUser(User user) throws SQLException, ClassNotFoundException;
	
	//public boolean saveManager(User user) throws SQLException, ClassNotFoundException;
	
	//sports
	/*
	Sports finBySportsId(int id) throws SQLException, ClassNotFoundException;
	
	List<Sports> getAllSports() throws SQLException, ClassNotFoundException;
	
	boolean updateSports(Sports sports) throws SQLException, ClassNotFoundException;
	
	boolean deleteSports(Sports sports) throws SQLException, ClassNotFoundException;
	
	public boolean addSports(Sports sports) throws SQLException, ClassNotFoundException;
	*/
}
	
	
	


