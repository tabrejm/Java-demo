package com.cybage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cybage.models.Enrollments;

@Repository
public interface EnrollmentsRepository extends JpaRepository<Enrollments, Long> {
	@Query("select e from Enrollments e where e.user=:id")
	Enrollments updateEnrollmentStatus(@Param("id")int id);

}
