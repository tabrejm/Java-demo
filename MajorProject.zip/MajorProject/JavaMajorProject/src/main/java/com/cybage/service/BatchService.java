package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.BatchNotFoundException;
import com.cybage.models.Batches;
import com.cybage.repository.BatchRepository;

@Service
public class BatchService {
	
	private BatchRepository batchrepository;
	
	@Autowired
	public BatchService(BatchRepository batchrepository) {
		this.batchrepository = batchrepository;
	}
	
	public Batches addBatch(Batches batch) {
		return batchrepository.save(batch);
	}
	
	public List<Batches> findAllBatches() {
		return batchrepository.findAll();
	}
	
	public Batches updateBatch(Batches batch) {
		return batchrepository.save(batch);
	}
	
	public Batches findById(Long id) {
		return batchrepository.findById(id).orElseThrow(() -> new BatchNotFoundException("Batch by id :"+id+" was not found!"));
	}
	
	/*
	public List<Batches> findByBatchName(String batchName) {
		return batchrepository.findBybatchName(batchName);
	}*/
	
	public void deleteBatch(Long id) {
		batchrepository.deleteById(id);
	}

}
