package com.cybage.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.models.Batches;

@Repository
public interface BatchRepository extends JpaRepository<Batches, Long> {

	Optional<Batches> findById(Long id);
	
	//List<Batches> findBybatchName(String batchName);


	
}
