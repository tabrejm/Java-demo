package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cybage.models.Sport;
import com.cybage.repository.SportRepository;

@Service
public class SportService {
	
	@Autowired
	SportRepository sportRepository;
	
	public List<Sport> getAllSports()
	{
		return sportRepository.findAll();
	}
	
//	public List<Sport> getSportByName(String sport_name)
//	{
//		return sportRepository.findBySportName(sport_name);
//	}
//	
	public Sport getSportById(int id)
	{
		return sportRepository.getById(id);
	}
	
	public void addSport(Sport sport)
	{
		sportRepository.save(sport);
	}
	
	public Sport updateSport(Sport sport,int sport_id)
	{
		Sport search_sport=sportRepository.getById(sport_id);
		if(search_sport!=null)
		{
		sportRepository.save(sport);
		return sport;
		}
		else 
          return null;
	}
	
	public void deleteSport(int sport_id)
	{
		sportRepository.deleteById(sport_id);
	}

	
	
	
	

}
