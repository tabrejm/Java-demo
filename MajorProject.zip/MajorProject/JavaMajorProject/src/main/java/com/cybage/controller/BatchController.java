	package com.cybage.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.models.Batches;
import com.cybage.service.BatchService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/batch")
public class BatchController {
	
	@Autowired
	private BatchService batchService;
	
	@GetMapping("/all")
	public ResponseEntity<List<Batches>> getAllBatches() {
		List<Batches> batches = batchService.findAllBatches();
		return new ResponseEntity<List<Batches>>(batches, HttpStatus.OK); 
	}
	
	@GetMapping("/find/{id}")
	public ResponseEntity<Batches> getaAllBatchById(@PathVariable("id") Long id) {
		Batches batch = batchService.findById(id);
		return new ResponseEntity<Batches>(batch, HttpStatus.OK); 
	}
	
	/*
	@GetMapping("/find/{batchName}")
	public ResponseEntity<List<Batches>> getByBatchName(@RequestParam String batchName) {
		List<Batches> findByBatchName = batchService.findByBatchName(batchName);
		return new ResponseEntity<List<Batches>>(findByBatchName, HttpStatus.OK); 
	}*/
	
	@PostMapping("/add")
	public ResponseEntity<Batches> addBatch(@RequestBody Batches batch) {
		Batches newBatch = batchService.addBatch(batch);
		return new ResponseEntity<Batches>(newBatch, HttpStatus.CREATED);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Batches> updateBatch(@PathVariable Long id,@RequestBody Batches batchDetails) {
		Batches batch = batchService.findById(id);
		
		batch.setBatchName(batchDetails.getBatchName());
		batch.setStartDate(batchDetails.getStartDate());
		batch.setEndDate(batchDetails.getEndDate());
		batch.setTime(batchDetails.getTime());
		batch.setImageUrl(batchDetails.getImageUrl());
		
		Batches updatedBatches = batchService.addBatch(batch);
		return new ResponseEntity<Batches>(updatedBatches, HttpStatus.OK); 
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Batches> deleteBatch(@PathVariable("id") Long id) {
		Batches batch = batchService.findById(id);
		
		batchService.deleteBatch(id);
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		response.put("deleted!!", Boolean.TRUE);
		return new ResponseEntity<Batches>(HttpStatus.OK);
	}

}
