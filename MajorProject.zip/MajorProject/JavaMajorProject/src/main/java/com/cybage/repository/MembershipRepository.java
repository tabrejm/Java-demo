package com.cybage.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.models.Membership;
import com.cybage.models.MembershipType;
import com.cybage.models.User;

@Repository
public interface MembershipRepository extends JpaRepository<Membership, Long>{
	
	Optional<Membership> findById(Long id);
	
	public Membership findByMembershipType(MembershipType membershipType);

}
