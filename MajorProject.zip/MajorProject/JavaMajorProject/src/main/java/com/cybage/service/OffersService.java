package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cybage.models.Offers;
import com.cybage.repository.OffersRepository;

@Service
public class OffersService {
	
	private List<Offers> offersList;
	
	@Autowired
	private OffersRepository offerRepository;
	
	public Offers addOffers(Offers offer) {
		return offerRepository.save(offer);
	}
	
	public List<Offers> getAllOffers() {
		return offerRepository.findAll();
	}
	

}
