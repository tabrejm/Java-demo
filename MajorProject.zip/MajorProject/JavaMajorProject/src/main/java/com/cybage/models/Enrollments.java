package com.cybage.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Enrollments {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Integer id;
	
	private Boolean approveRequest;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	public Enrollments() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Enrollments(Boolean approveRequest) {
		super();
		this.approveRequest = approveRequest;
	}




	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getApproveRequest() {
		return approveRequest;
	}

	public void setApproveRequest(Boolean approveRequest) {
		this.approveRequest = approveRequest;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

}
