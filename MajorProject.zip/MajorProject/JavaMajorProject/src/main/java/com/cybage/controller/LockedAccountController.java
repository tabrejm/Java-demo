package com.cybage.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cybage.models.LockAccount;
import com.cybage.service.LockedAccountService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/lock_account")
public class LockedAccountController {
	
	@Autowired
	private LockedAccountService lockAccountService;
	
	@GetMapping("/all")
	public ResponseEntity<List<LockAccount>> getAllLockAccounts() {
		List<LockAccount> lock_accounts = lockAccountService.getAllLockedAccounts();
		return new ResponseEntity<List<LockAccount>>(lock_accounts, HttpStatus.OK); 
	}
	
	@GetMapping("/find/{id}")
	public ResponseEntity<LockAccount> getLockAccountById(@PathVariable("id") int id) {
		LockAccount lockAccount =lockAccountService.getByLockedAccountById(id);
		return new ResponseEntity<LockAccount>(lockAccount, HttpStatus.OK); 
	}
	
	@GetMapping("/find_email/{email}")
	public ResponseEntity<?> getLockAccountByEmail(@PathVariable("email") String email) {
		LockAccount lockAccount =lockAccountService.getByLockedAccountByEmail(email);
		if(lockAccount!=null)
		{
		return new ResponseEntity<LockAccount>(lockAccount, HttpStatus.OK); 
		}
		else
			return new ResponseEntity<String>("Email not found", HttpStatus.NOT_FOUND); 

	}
	
	@PostMapping("/add")
	public ResponseEntity<LockAccount> addLockAccount(@RequestBody LockAccount lockAccount) {
		LockAccount lock_Account = lockAccountService.addLockedAccount(lockAccount);
		return new ResponseEntity<LockAccount>(lock_Account, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteLockAccount(@PathVariable int id) {

		lockAccountService.deleteLockedAccountById(id);
		return new ResponseEntity<String>("Account unlocked",HttpStatus.OK);
	}

}
