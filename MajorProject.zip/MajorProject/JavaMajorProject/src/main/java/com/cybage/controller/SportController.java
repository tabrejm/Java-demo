package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.exception.SportCustomException;
import com.cybage.models.Sport;
import com.cybage.service.SportService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/sport")
public class SportController {
	
	@Autowired
	SportService sportService;
	
	@GetMapping("/getAllSports")
	public ResponseEntity<?> getAllSport()
	{
		return new ResponseEntity<List<Sport>>(sportService.getAllSports(),HttpStatus.OK);
	}
	
	@GetMapping("/get_sport/{id}")
	public ResponseEntity<?> searchSportById(@PathVariable int id)
	{
		Sport sport=sportService.getSportById(id);
		if(sport!=null)
		{
			return new ResponseEntity<Sport>(sport,HttpStatus.OK);
		}
		else
			throw new SportCustomException("Sport not found due to invalid sport id !");
	}


	@PostMapping("/addSport")
	public ResponseEntity<String> registerSport(@RequestBody Sport sport,BindingResult bindingResult)
	{
		System.out.println("Register");
		if(bindingResult.hasErrors())
		{
			throw new SportCustomException("Sport not added !");
		}
		else
		{
			sportService.addSport(sport);
			return new ResponseEntity<String>("Sport added successfully",HttpStatus.CREATED);

		}
	}
	
	@PutMapping("/edit")
	public ResponseEntity<?> editSport(@RequestBody Sport sport,BindingResult bindingResult)
	{
		Sport updated_sport=sportService.updateSport(sport,sport.getSport_id());
		if(updated_sport==null || bindingResult.hasErrors())
		{
			throw new SportCustomException("Sport updation failed !");
		}
		else
		{
			return new ResponseEntity<Sport>(updated_sport,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteSport(@PathVariable int id)
	{
		Sport deleted_sport=sportService.getSportById(id);
		if(deleted_sport==null)
		{
			throw new SportCustomException("Sport deletion failed due to invalid sport id!");
		}
		else
		{
			sportService.deleteSport(id);
			return new ResponseEntity<String>("Sport deleted successfully !",HttpStatus.OK);
		}
	}
	
}
