package com.cybage.exception;

@SuppressWarnings("serial")
public class SportCustomException extends RuntimeException{

	public SportCustomException(String message) {
		super(message);
	}
}
